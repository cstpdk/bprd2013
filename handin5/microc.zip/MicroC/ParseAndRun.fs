(* File MicroC/ParseAndRun.fs *)

let fromString = Parse.fromString

let fromFile = Parse.fromFile

let run = Interp.run
